#!/bin/RScript
#HSD
#AML
#Drive conversion rate separate

rm(list=ls())
wd<-"/Users/weizhechen/Documents/ML/Jie" #set working directory
setwd(wd)

#Packages----
library(ggplot2)

#ML framework----
source("/Users/weizhechen/Documents/ML/Jie/src_ne/HSD-AML-Jie-ML-DRmf.R")

#Global Variables----

CAGE1.PATH<-"/Users/weizhechen/Documents/ML/Jie/raw_cage_XnGr.txt" 
CAGE2.PATH<-"/Users/weizhechen/Documents/ML/Jie/raw_cage_DsG.txt"

DRm.a.X<-0.755
DRf.a.X<-0.501 #drive conversion rate, cage 1 (XnGr)

DRm.a.D<-0.832
DRf.a.D<-0.459 #drive conversion rate, cage 2 (DsG) 

DRR.a.X<-0.2 #germline resistance formation rate, cage 1
DRR.a.D<-0.2 #germline resistance formation rate, cage 2


ER.a<-0.05 #embryo resistance formation rate, cage 1 & 2 
H.a<-1 #ratio of drive heterozygotes in generation 0, cage 1 & 2. 释放的Drive carriers中drive杂合子占比

X.ab <- 1 #germline cut rate, off-target, all cages 
E.ab <- 0 #embryo cut rate, off-target, all cages
T.ab <- 0.5 #already cut in generation 0, off-target, all cages ??

#modes setting 
MODES.a<-c(10) #tested modes, cage 1 & 2 
D.ab<-rep("c",3) #fitness modes (mate choice, fecundity, viability) drive, all cages 
O.ab<-rep("c",3) #fitness modes (mate choice, fecundity, viability) off-target, all cages

#ML相关参数
DIST.ab<-0.01 #convergence distance for CI determination, all cages 收敛区间
A.ab<-0.05 #type 1 error, all cages  P<0.05
RM.START<-0 #number of generations to remove from the beginning of an experiment 最初代的fitness不稳定
D.LIM<-0 #add to 1 for upper limit for drive fitness estimate in ML
O.LIM<-0 #add to  1 for upper limit for off-target fitness estimate in ML

TOSTORE.ab<-"/Users/weizhechen/Documents/ML/Jie/OUTPUT/" #store ML output, all cages


#Additional Functions----
#1. read_emp_data 
#x = path to empirical cage data (.txt)
#return = data frame formatted for ML approach
read_emp_data<-function(x){
  y<-read.table(x)
  colnames(y)<-c("g","r","wt","N")   
  y$N<-NULL
  return(y)
  }

#2. plot_emp_data
#x = output from read_emp_data()
#return = drive carrier frequency plot over time 
plot_emp_data<-function(x){
  y<-x
  y$r<-x$r/(x$r+x$wt)   #r ratio
  y$wt<-x$wt/(x$wt+x$r) #wt ratio
  y$g<-as.factor(y$g)   
  g<-ggplot(data=y,aes(x=g,y=r))+geom_line(col="red",group=1)+geom_point(col="red")
  g<-g+theme_minimal()+coord_cartesian(ylim = c(0,1),xlim=c(0,25))
  g<-g+scale_y_continuous("f(r)",breaks = c(0,0.25,0.5,0.75,1))
  g<-g+xlab("Generation")+theme(text=element_text(size = 15))
  g<-g+scale_x_discrete("Generation",breaks=seq(0,25,5))
  return(g)
}

#Load & EDA Data----

cage1<-read_emp_data(CAGE1.PATH)
cage2<-read_emp_data(CAGE2.PATH)


plot_emp_data(cage1)
plot_emp_data(cage2)


#if(RM.START>0){ #remove generations at the beginning of experiment (optional)
#  cage1<-cage1[-c(1:RM.START),]  #去掉g=0的起始数据
#  cage1$g<-cage1$g-RM.START      #generation从头开始设置成g=0
#  cage2<-cage2[-c(1:RM.START),]
#  cage2$g<-cage2$g-RM.START
#}



#ML cage 1 (separate analysis)----XnGr
obs.data<-list()
obs.data[[1]]<-cage1

for(mode.iter in MODES.a){
  print(paste("Mode:",mode.iter)) #determine limits
  my.res.iter<-list() #set storage for individual runs 
  toStore<-paste(TOSTORE.ab,"ML-cage1-DRmf-mode",mode.iter,".rds",sep="")
  my.lim.iter<-set_limits(fmode = mode.iter,fd.lim = D.LIM,fo.lim = O.LIM) #determine parameters to estimate
  print("Limits:")
  print(my.lim.iter)
  print(paste("Storage:",toStore))
  
  
  if(mode.iter==10) { #reset D.ab for leaky somatic expression
    D.ab<-c("n","l","n")
  } else {
    D.ab<-rep("c",3)
  }
  
  #ML estimate: 
  ml<-optim(my.lim.iter[[2]],logL,method = "L-BFGS-B",control = list(fnscale=-1),
            lower = my.lim.iter[[1]],upper = my.lim.iter[[3]],
            lN=obs.data,ld=D.ab,lo=O.ab,lt=T.ab,lmpath=M.path,
            lg=G,lx=X.ab,le=E.ab,ldrm=DRm.a.X,ldrf=DRf.a.X,ldrr=DRR.a.X,ler=ER.a,lh=H.a,lmode=mode.iter)
  print(ml)
  
  #AICc calculation:
  n.trans<-sum(unlist(lapply(obs.data,function(k) nrow(k)-1)))
  print(paste("Number of transistions:",n.trans))
  aicc<-calculate_AICc(flnL = ml$value,p = length(my.lim.iter[[2]]),n = n.trans)
  print(paste("AICc:",aicc))
  
  #CI estimate:
  ci<-calculate_CI(fml = ml,fN = obs.data,fdist = DIST.ab,fa = A.ab,
                   fd = D.ab,fo = O.ab,fg = G,ft = T.ab,fmpath = M.path,
                   fx = X.ab,fe = E.ab,fdrm = DRm.a.X,fdrf = DRf.a.X,fdrr = DRR.a.X,fer = ER.a,
                   fh = H.a,fmode = mode.iter)
  print("CI interval:")
  print(ci)
  
  my.res.iter[[1]]<-ml
  my.res.iter[[2]]<-aicc
  my.res.iter[[3]]<-ci
  
  saveRDS(my.res.iter,toStore)
  rm(my.res.iter,ci,aicc,n.trans,ml,toStore,my.lim.iter)
  print("------------------")
}

#ML cage 2 (separate)----DsG
obs.data<-list()
obs.data[[1]]<-cage2


for(mode.iter in MODES.a){
  print(paste("Mode:",mode.iter)) #determine limits
  my.res.iter<-list() #set storage for individual runs 
  toStore<-paste(TOSTORE.ab,"ML-cage2-DRmf-mode",mode.iter,".rds",sep="")
  my.lim.iter<-set_limits(fmode = mode.iter,fd.lim = D.LIM,fo.lim = O.LIM) #determine parameters to estimate
  print("Limits:")
  print(my.lim.iter)
  print(paste("Storage:",toStore))
  
  
  if(mode.iter==10) { #reset D.ab for leaky somatic expression
    D.ab<-c("n","l","n")
  } else {
    D.ab<-rep("c",3)
  }
  
  #ML estimate: 
  ml<-optim(my.lim.iter[[2]],logL,method = "L-BFGS-B",control = list(fnscale=-1),
            lower = my.lim.iter[[1]],upper = my.lim.iter[[3]],
            lN=obs.data,ld=D.ab,lo=O.ab,lt=T.ab,lmpath=M.path,
            lg=G,lx=X.ab,le=E.ab,ldrm=DRm.a.D,ldrf=DRf.a.D,ldrr=DRR.a.D,ler=ER.a,lh=H.a,lmode=mode.iter)
  print(ml)
  
  #AICc calculation:
  n.trans<-sum(unlist(lapply(obs.data,function(k) nrow(k)-1)))
  print(paste("Number of transistions:",n.trans))
  aicc<-calculate_AICc(flnL = ml$value,p = length(my.lim.iter[[2]]),n = n.trans)
  print(paste("AICc:",aicc))
  
  #CI estimate:
  ci<-calculate_CI(fml = ml,fN = obs.data,fdist = DIST.ab,fa = A.ab,
                   fd = D.ab,fo = O.ab,fg = G,ft = T.ab,fmpath = M.path,
                   fx = X.ab,fe = E.ab,fdrm = DRm.a.D,fdrf = DRf.a.D, fdrr = DRR.a.D,fer = ER.a,
                   fh = H.a,fmode = mode.iter)
  print("CI interval:")
  print(ci)
  
  my.res.iter[[1]]<-ml
  my.res.iter[[2]]<-aicc
  my.res.iter[[3]]<-ci
  
  saveRDS(my.res.iter,toStore)
  rm(my.res.iter,ci,aicc,n.trans,ml,toStore,my.lim.iter)
  print("------------------")
}
