#### Data and code for Wang E, Metzloff M, Langmüller AM, Clark AG, Messer PW, Champer J., A homing suppression gene drive with multiplexed gRNAs maintains high drive conversion efficiency and avoids functional resistance alleles, bioRxiv, May 2021.

---

All revision is based on HSD_AML_20210305_code_call-ML.R and HSD-AML-20210305-ML-v2.R
### src/HSD_AML_20210305_code_call-ML.R:
R-code to quantify the fitness costs of the gene drive from the observed frequency trajectories in our D. melanogaster cage populations. Uses functions implemented in HSD-AML-20210305-ML-v2.R

### src/HSD-AML-20210305-ML-v2.R:
R-code of previously developed maximum likelihood framework (https://doi.org/10.1534/genetics.118.301893) modified to model a homing suppression drive.

###HSD_AML_Jie_call-ML-DRmf.R:
1. separate male and female drive conversion

###HSD_AML_Jie_call-ML.R:
1. infer with skipping some strange generation 

###HSD_AML_Jie_call-ML2.R:
1. ne -> %ne, population size is the average of each generation on either side of the transition (based on observe data)
2. can infer with skipping some strange generation 

### data/:
Data used by the maximum likelihood framework. HSD_AML_20210201_data_trans-matrix-FILLED.csv contains expected offspring count for each genotype combination (2 independent loci (drive/off-target)). 

### !NOTE!
Cage XnGr in the manuscript = cage 1 in the R-code.
Cage DsG in the manuscript = cage 2 in the R-code.
