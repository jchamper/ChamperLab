#### Data and code for haplosufficient homing rescue modification drive

---

### Model/HDREh_AML_Shibo_call-ML-v3.R:
R-code to quantify the fitness costs of the gene drive from the observed frequency trajectories in our D. melanogaster cage populations (drive individuals cross with resistance individuals). Uses functions implemented in HDREh-AML-Shibo-ML-v3

### Model/HDREh_AML_Shibo_call-ML-v9.R:
R-code to estimate resistance allele formation rate and fixed r1 resistance allele formation rate from the observed frequency trajectories in our D. melanogaster cage populations. Uses functions implemented in HDREh-AML-Shibo-ML-v9.R (mode20)

### Model/HDREh_AML_Shibo_call-ML-v10.R:
R-code to estimate resistance allele formation rate and varying r1 resistance allele formation rate from the observed frequency trajectories in our D. melanogaster cage populations. Uses functions implemented in HDREh-AML-Shibo-ML-v10.R (mode22)

### Model/HDREh-AML-Shibo-ML-v3.R:
R-code of previously developed maximum likelihood framework (https://doi.org/10.1534/genetics.118.301893) modified to model a haplosufficient homing rescue modification drive.

### Model/HDREh-AML-Shibo-ML-v9.R:
R-code of previously developed maximum likelihood framework (https://doi.org/10.1534/genetics.118.301893) modified to model a homing suppression drive & estimate germline resistance allele formation rate and fixed R1 formation rate. 

### Model/HDREh-AML-Shibo-ML-v9.R:
R-code of previously developed maximum likelihood framework (https://doi.org/10.1534/genetics.118.301893) modified to model a homing suppression drive & estimate germline resistance allele formation rate and varying R1 formation rate.

### Model/HSD_AML_20210518_data_trans-matrix-FILLED:
HSD_AML_20210518_data_trans-matrix-FILLED contains expected offspring count for each genotype combination (1 drive locus, 4 alleles: wild type, drive, r1, r2)

### Data/:
raw_cage[123].txt contain the raw genotype counts of our D. melanogaster cage populations.


