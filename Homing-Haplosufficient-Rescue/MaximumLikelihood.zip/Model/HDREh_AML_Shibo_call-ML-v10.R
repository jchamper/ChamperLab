#!/bin/RScript
#HSD
#AML
#v10: varying r2 resistance rate and r1 formation rate


rm(list=ls())
setwd("D:/pku/gene drive/maximum likelihood method/HomingRescueDrive-ML")
getwd()
#Packages----
library(ggplot2)

#ML framework----
source("./Model/HDREh-AML-Shibo-ML-v10.R")

#Global Variables----

CAGE1.PATH<-"D:/pku/gene drive/maximum likelihood method/Shibo/raw_cage_1.txt" #empirical data
CAGE2.PATH<-"D:/pku/gene drive/maximum likelihood method/Shibo/raw_cage_2.txt"
#CAGE3.PATH<-"D:/pku/gene drive/maximum likelihood method/G3-HomingSuppressionDrive-main/HomingSuppressionDrive-main/data/raw_cage3.txt"

DRm.a<-0.3571 #male drive conversion rate, cage 1 & 2
#DRf.a<-2*0.6862*(1-DRR.a*ER.a-(1-DRR.a)*ER.a^2) #female drive conversion rate, cage 1 & 2
DRR.a<-0.20 #germline resistance formation rate, cage 1 & 2 (if not estimated)
#ER.a<-DRR.a/2 #embryo resistance formation rate, cage 1 & 2 
H.a<-0 #ratio of drive heterozygotes in generation 0, cage 1 & 2


DR.b<-0 #drive conversion rate, cage 3
DRR.b<-0 #germline resistance formation raste, cage 3
ER.b<-0 #embryo resistance formation rate, cage 3
H.b<-0.59 #ratio of drive heterozygotes in generation 0, cage 3 

MODES.a<-c(22) #tested modes, cage 1 & 2  c(0,1,3,10,13,14)
MODES.b<-c(14) #tested modes, cage 3 

D.ab<-rep("c",3) #fitness modes (mate choice, fecundity, viability) drive, all cages 
R1.ab<-0 #r1 resistance formation rate, all cages (if not estimated)

DIST.ab<-0.001 #convergence distance for CI determination, all cages0.005
A.ab<-0.05 #type 1 error, all cages 
RM.START<-0 #number of generations to remove from the beginning of an experiment
D.LIM<-0.1 #add to 0.9 for upper limit for drive fitness estimate in ML

TOSTORE.ab<-"./" #store ML output, all cages


#Additional Functions----

#read_emp_data
#x ... path to empirical cage data (.txt)
#return(y) ... data frame formatted for ML approach
read_emp_data<-function(x){
  y<-read.table(x)
  colnames(y)<-c("g","r","wt","N")
  y$N<-NULL
  return(y)
  }

#plot_emp_data
#x ... output from read_emp_data()
#return(y) ... drive carrier frequency plot over time 
plot_emp_data<-function(x){
  y<-x
  y$r<-x$r/(x$r+x$wt)
  y$wt<-x$wt/(x$wt+x$r)
  y$g<-as.factor(y$g)
  g<-ggplot(data=y,aes(x=g,y=r))+geom_line(col="red",group=1)+geom_point(col="red")
  g<-g+theme_minimal()+coord_cartesian(ylim = c(0,1),xlim=c(0,25))
  g<-g+scale_y_continuous("f(r)",breaks = c(0,0.25,0.5,0.75,1))
  g<-g+xlab("Generation")+theme(text=element_text(size = 15))
  g<-g+scale_x_discrete("Generation",breaks=seq(0,25,5))
  return(g)
}

#Load & EDA Data----

(cage1<-read_emp_data(CAGE1.PATH))
(cage2<-read_emp_data(CAGE2.PATH))
#(cage3<-read_emp_data(CAGE3.PATH))


plot_emp_data(cage1)
plot_emp_data(cage2)
#plot_emp_data(cage3)

if(RM.START>0){ #remove generations at the beginning of experiment (optional)
  cage1<-cage1[-c(1:RM.START),]
  cage1$g<-cage1$g-RM.START
  cage2<-cage2[-c(1:RM.START),]
  cage2$g<-cage2$g-RM.START
  #cage3<-cage3[-c(1:RM.START),]
  #cage3$g<-cage3$g-RM.START
}

#ML cage 1&2 (joint analysis)----
obs.data<-list()
obs.data[[1]]<-cage1
obs.data[[2]]<-cage2

print(obs.data)
for(mode.iter in MODES.a){
  print(paste("Mode:",mode.iter)) #determine limits
  my.res.iter<-list() #set storage for individual runs 
  toStore<-paste(TOSTORE.ab,"ML-cage12-mode",mode.iter,".rds",sep="")
  my.lim.iter<-set_limits(fmode = mode.iter,fd.lim = D.LIM) #determine parameters to estimate
  print("Limits:")
  print(my.lim.iter)
  print(paste("Storage:",toStore))
  
  if(mode.iter%in%c(10,13)==T) { #reset D.ab for leaky somatic expression
    D.ab<-c("n","l","n")
  } else {
    D.ab<-rep("c",3)
  }
  print(paste("Mode",mode.iter,"D",D.ab[2],sep = ":"))
  #print(obs.data)
  #ML estimate: 
  ml<-optim(my.lim.iter[[2]],logL,method = "L-BFGS-B",control = list(fnscale=-1),
            lower = my.lim.iter[[1]],upper = my.lim.iter[[3]],
            lN=obs.data,ld=D.ab,lmpath=M.path,
            lg=G,ldr=DRm.a,ldrr=DRR.a,lh=H.a,lr1=R1.ab,lmode=mode.iter)
  print(ml)
  
  #AICc calculation:
  n.trans<-sum(unlist(lapply(obs.data,function(k) nrow(k)-1)))
  print(paste("Number of transistions:",n.trans))
  aicc<-calculate_AICc(flnL = ml$value,p = length(my.lim.iter[[2]]),n = n.trans)
  print(paste("AICc:",aicc))
  
  #CI estimate:
  ci<-calculate_CI(fml = ml,fN = obs.data,fdist = DIST.ab,fa = A.ab,
                   fd = D.ab,fg = G,fmpath = M.path,fdr = DRm.a,fdrr = DRR.a,fh = H.a,fmode = mode.iter,fr1 = R1.ab)
  print("CI interval:")
  print(ci)
  
  my.res.iter[[1]]<-ml
  my.res.iter[[2]]<-aicc
  my.res.iter[[3]]<-ci
  
  saveRDS(my.res.iter,toStore)
  rm(my.res.iter,ci,aicc,n.trans,ml,toStore,my.lim.iter)
  print("------------------")
}

#ML cage 2 (separate analysis)----
obs.data<-list()
obs.data[[1]]<-cage2


for(mode.iter in MODES.a){
  print(paste("Mode:",mode.iter)) #determine limits
  my.res.iter<-list() #set storage for individual runs 
  toStore<-paste(TOSTORE.ab,"ML-cage1-mode",mode.iter,".rds",sep="")
  my.lim.iter<-set_limits(fmode = mode.iter,fd.lim = D.LIM) #determine parameters to estimate
  print("Limits:")
  print(my.lim.iter)
  print(paste("Storage:",toStore))
  
  
  if(mode.iter%in%c(10,13)==T) { #reset D.ab for leaky somatic expression
    D.ab<-c("n","l","n")
  } else {
    D.ab<-rep("c",3)
  }
  print(paste("Mode",mode.iter,"D",D.ab[2],sep = ":"))
  
  #ML estimate: 
  ml<-optim(my.lim.iter[[2]],logL,method = "L-BFGS-B",control = list(fnscale=-1),
            lower = my.lim.iter[[1]],upper = my.lim.iter[[3]],
            lN=obs.data,ld=D.ab,lmpath=M.path,
            lg=G,ldr=DRm.a,ldrr=DRR.a,lh=H.a,lr=R1.ab,lmode=mode.iter)
  print(ml)
  
  #AICc calculation:
  n.trans<-sum(unlist(lapply(obs.data,function(k) nrow(k)-1)))
  print(paste("Number of transistions:",n.trans))
  aicc<-calculate_AICc(flnL = ml$value,p = length(my.lim.iter[[2]]),n = n.trans)
  print(paste("AICc:",aicc))
  
  #CI estimate:
  ci<-calculate_CI(fml = ml,fN = obs.data,fdist = DIST.ab,fa = A.ab,
                   fd = D.ab,fg = G,fmpath = M.path,
                   fdr = DRm.a,fdrr = DRR.a,
                   fh = H.a,fr1 = R1.ab, fmode = mode.iter)
  print("CI interval:")
  print(ci)
  
  my.res.iter[[1]]<-ml
  my.res.iter[[2]]<-aicc
  my.res.iter[[3]]<-ci
  
  saveRDS(my.res.iter,toStore)
  rm(my.res.iter,ci,aicc,n.trans,ml,toStore,my.lim.iter)
  print("------------------")
}


#ML cage 1 (separate analysis)----
obs.data<-list()
obs.data[[1]]<-cage1


for(mode.iter in MODES.a){
  print(paste("Mode:",mode.iter)) #determine limits
  my.res.iter<-list() #set storage for individual runs 
  toStore<-paste(TOSTORE.ab,"ML-cage1-mode",mode.iter,".rds",sep="")
  my.lim.iter<-set_limits(fmode = mode.iter,fd.lim = D.LIM) #determine parameters to estimate
  print("Limits:")
  print(my.lim.iter)
  print(paste("Storage:",toStore))
  
  
  if(mode.iter%in%c(10,13)==T) { #reset D.ab for leaky somatic expression
    D.ab<-c("n","l","n")
  } else {
    D.ab<-rep("c",3)
  }
  print(paste("Mode",mode.iter,"D",D.ab[2],sep = ":"))
  
  #ML estimate: 
  ml<-optim(my.lim.iter[[2]],logL,method = "L-BFGS-B",control = list(fnscale=-1),
            lower = my.lim.iter[[1]],upper = my.lim.iter[[3]],
            lN=obs.data,ld=D.ab,lmpath=M.path,
            lg=G,ldr=DRm.a,ldrr=DRR.a,lh=H.a,lr=R1.ab,lmode=mode.iter)
  print(ml)
  
  #AICc calculation:
  n.trans<-sum(unlist(lapply(obs.data,function(k) nrow(k)-1)))
  print(paste("Number of transistions:",n.trans))
  aicc<-calculate_AICc(flnL = ml$value,p = length(my.lim.iter[[2]]),n = n.trans)
  print(paste("AICc:",aicc))
  
  #CI estimate:
  ci<-calculate_CI(fml = ml,fN = obs.data,fdist = DIST.ab,fa = A.ab,
                   fd = D.ab,fg = G,fmpath = M.path,
                   fdr = DRm.a,fdrr = DRR.a,
                   fh = H.a,fr1 = R1.ab,fmode = mode.iter)
  print("CI interval:")
  print(ci)
  
  my.res.iter[[1]]<-ml
  my.res.iter[[2]]<-aicc
  my.res.iter[[3]]<-ci
  
  saveRDS(my.res.iter,toStore)
  rm(my.res.iter,ci,aicc,n.trans,ml,toStore,my.lim.iter)
  print("------------------")
}


